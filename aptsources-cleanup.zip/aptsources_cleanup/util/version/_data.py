# -*- coding: utf-8
import datetime

version = '0.1.6.6'
date = datetime.datetime(2019, 10, 27, 13, 58, 42, tzinfo=datetime.timezone(datetime.timedelta(0, 3600)))
commit = '6306f12cadc46128c22f2c190f7f13ec88b0ff06'
branch_name = 'master'
